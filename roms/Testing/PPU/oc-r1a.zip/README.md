Overclock measuring ROM
=======================

Some people like to overclock the NES CPU to reduce slowdown in
games.  This program attempts to measure the clock rate of the NES
using the length of a scanline as a time base.

Though the NES has no real-time clock, a program can measure the
clock rate relative to the PPU's ~15.7 kHz horizontal retrace.
This frequency cannot be changed without causing the TV to lose
color or even lose sync.

Then it uses NMI and sprite 0 timing to measure cycles per frame and
per scanline.  It guesses the hsync rate based on whether the PPU is
making 262 or 312 lines.  (NTSC PPUs use 15745.80 Hz, while PAL PPUs
use 15602.18 Hz.)  Finally it calculates CPU clock speed.
  
Methodology
-----------

Because of the way the NES encodes hue into a composite signal, all
NES PPUs use a master clock that is 6 times the TV system's color
burst frequency. Then they divide the master clock by a scale factor
such that 341 dots are close to the system's scanline period.

    PAL colorburst: 4433618.75 Hz
    PAL master clock: 26601712.5 Hz
    PAL divider: 5 master clocks per dot
    PAL dot rate: 5320342.5 Hz
    PAL line rate: 15602.18 Hz
    PAL lines per field: 312

    NTSC colorburst: 315/88 MHz = 3579545.45 Hz
    NTSC master clock: 21477272.7 Hz
    NTSC divider: 4 master clocks per dot
    NTSC dot rate: 5369318.2 Hz
    NTSC line rate: 15745.80 Hz
    NTSC lines per field: 262
    
    315/88×6000000÷4÷341

The NES PPU has a bit in its status register for whether an opaque
pixel of sprite 0 has overlapped an opaque pixel of the background
so far this frame.  It turns on when the PPU detects this overlap
and turns off during vertical blanking.  It has a second bit in its
status register that turns on when it finds too many sprites on one
scanline and turns off during vertical blanking.

To determine CPU cycles per scanline, the test program counts cycles
between when the too many sprites bit rises (changes from 0 to 1)
and when the sprite 0 bit rises. This test is performed with sprite
0 near the bottom and all other sprites near the top. To determine
CPU cycles per field, it uses the same setup and counts cycles
between when the sprite 0 bit rises in one frame and when it rises
in the next.

The program proceeds to guess whether the line rate is NTSC or PAL.
If there are more than about 288 lines per frame, it assumes the
line rate is PAL; otherwise, it's assumed NTSC. (This methodology
assumes that only the CPU has been overclocked, not the PPU.
Overclocking the PPU could cause loss of color in mild cases or loss
of horizontal sync in stronger cases.  It further assumes that all
312-line systems are PAL and that all 262-line PPUs are NTSC, that
there are no PAL/M clone PPUs.)

At this point, the test program has cycles per field, cycles per
scanline, and scanlines per second.  This is enough to calculate
cycles per second and fields per second.

Low-level calculation method
----------------------------

We'll need a 24/16 divider, a 16*16 multiplier, and a binary to
decimal converter.

* frame_time and time_192_lines are in units of 12 cycles
* cycles per 10 lines = time_192_lines * 12 * 10 / 192 = time_192_lines * 5 / 8
* scanlines per frame = round(frame_time * 192 / time_192_lines)
* tv system = "PAL" if frame_time >= time_192_lines * 3 / 2 else "NTSC"
* frame rate = line_rate_in_cHz / scanlines_per_frame
* cycles per ms = time_192_lines * line_rate_in_Hz / 16000 = time_192_lines * (line_rate_in_Hz * 4.096) / 65536
* line_rate_in_Hz * 4.096 is 64494 for NTSC or 63907 for PAL

NTSC might give frame_time = $9B0 = 2480 and time_192_lines = $71A = 1818

Legal
-----
The test is distributed under the following terms:

    Copyright 2015 Damian Yerrick
    Copying and distribution of this file, with or without
    modification, are permitted in any medium without royalty
    provided the copyright notice and this notice are preserved.
    This file is offered as-is, without any warranty.
